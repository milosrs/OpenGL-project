﻿// -----------------------------------------------------------------------
// <file>World.cs</file>
// <copyright>Grupa za Grafiku, Interakciju i Multimediju 2013.</copyright>
// <author>Srđan Mihić</author>
// <author>Aleksandar Josić</author>
// <summary>Klasa koja enkapsulira OpenGL programski kod.</summary>
// -----------------------------------------------------------------------
using System;
using Assimp;
using System.IO;
using System.Reflection;
using SharpGL.SceneGraph;
using SharpGL.SceneGraph.Primitives;
using SharpGL.SceneGraph.Quadrics;
using SharpGL.SceneGraph.Core;
using SharpGL;

namespace AssimpSample
{


    /// <summary>
    ///  Klasa enkapsulira OpenGL kod i omogucava njegovo iscrtavanje i azuriranje.
    /// </summary>
    public class World : IDisposable
    {
        #region Atributi

        /// <summary>
        ///	 Ugao rotacije Meseca
        /// </summary>
        private float m_moonRotation = 0.0f;

        /// <summary>
        ///	 Ugao rotacije Zemlje
        /// </summary>
        private float m_earthRotation = 0.0f;

        /// <summary>
        ///	 Scena koja se prikazuje.
        /// </summary>
        private AssimpScene m_scene;

        /// <summary>
        ///	 Ugao rotacije sveta oko X ose.
        /// </summary>
        private float m_xRotation = 0.0f;

        /// <summary>
        ///	 Ugao rotacije sveta oko Y ose.
        /// </summary>
        private float m_yRotation = 0.0f;

        /// <summary>
        ///	 Udaljenost scene od kamere.
        /// </summary>
        private float m_sceneDistance = 30.0f;
        
        /// <summary>
        ///	 Sirina OpenGL kontrole u pikselima.
        /// </summary>
        private int m_width;

        /// <summary>
        ///	 Visina OpenGL kontrole u pikselima.
        /// </summary>
        private int m_height;

        /// <summary>
        ///	 Osnovni cilindar za crtanje.
        /// </summary>
        private Cylinder cyl;

        /// <summary>
        ///	 Osnovna kocka za crtanje.
        /// </summary>
        private Cube cub;

        #endregion Atributi

        #region Properties

        /// <summary>
        ///	 Scena koja se prikazuje.
        /// </summary>
        public AssimpScene Scene
        {
            get { return m_scene; }
            set { m_scene = value; }
        }

        /// <summary>
        ///	 Ugao rotacije sveta oko X ose.
        /// </summary>
        public float RotationX
        {
            get { return m_xRotation; }
            set { m_xRotation = value; }
        }

        /// <summary>
        ///	 Ugao rotacije sveta oko Y ose.
        /// </summary>
        public float RotationY
        {
            get { return m_yRotation; }
            set { m_yRotation = value; }
        }

        /// <summary>
        ///	 Udaljenost scene od kamere.
        /// </summary>
        public float SceneDistance
        {
            get { return m_sceneDistance; }
            set { m_sceneDistance = value; }
        }

        /// <summary>
        ///	 Sirina OpenGL kontrole u pikselima.
        /// </summary>
        public int Width
        {
            get { return m_width; }
            set { m_width = value; }
        }

        /// <summary>
        ///	 Visina OpenGL kontrole u pikselima.
        /// </summary>
        public int Height
        {
            get { return m_height; }
            set { m_height = value; }
        }

        #endregion Properties

        #region Konstruktori

        /// <summary>
        ///  Konstruktor klase World.
        /// </summary>
        public World(String scenePath, String sceneFileName, int width, int height, OpenGL gl)
        {
            this.m_scene = new AssimpScene(scenePath, sceneFileName, gl);
            this.m_width = width;
            this.m_height = height;
            this.cyl = new Cylinder();
            this.cub = new Cube();
        }

        /// <summary>
        ///  Destruktor klase World.
        /// </summary>
        ~World()
        {
            this.Dispose(false);
        }

        #endregion Konstruktori

        #region Metode

        /// <summary>
        ///  Korisnicka inicijalizacija i podesavanje OpenGL parametara.
        /// </summary>
        public void Initialize(OpenGL gl)
        {

            gl.ClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            gl.Color(1f, 0f, 0f);
            // Model sencenja na flat (konstantno)
            gl.ShadeModel(OpenGL.GL_FLAT);
            gl.Enable(OpenGL.GL_DEPTH_TEST); //Ukljuceno testiranje dubine
            gl.Enable(OpenGL.GL_CULL_FACE); //Ukljuceno sakrivanje nevidljivih povrsina 
            m_scene.LoadScene();
            m_scene.Initialize();
            cyl.CreateInContext(gl);
            
        }

        /// <summary>
        ///  Iscrtavanje OpenGL kontrole.
        /// </summary>
        public void Draw(OpenGL gl)
        {
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);


            Draw_Ground(gl);
            Draw_Human(gl);
            Draw_Stairs(gl);
            Draw_Info(gl);
            gl.Flush();
        }

        /// <summary>
        /// Iscrtavanje podloge za scenu.
        /// </summary>
        public void Draw_Ground(OpenGL gl) {

            gl.PushMatrix();
            gl.Translate(0.0f, 0.0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Begin(OpenGL.GL_QUADS);

            gl.Normal(0.0f, 1.0f, 0.0f);
            gl.Scale(5, 5, 5);
            gl.Color(1.0f, 0.0f, 0.0f);
       
            gl.Vertex(-20.0f, -6.0f, 0.0f);           
            gl.Vertex(20.0f, -6.0f, 0.0f);          
            gl.Vertex(20.0f, -6.0f, -50.0f);
            gl.Vertex(-20.0f, -6.0f, -50.0f);
            gl.End();
            gl.PopMatrix();

        }

        /// <summary>
        /// Iscrtavanje coveka za scenu.
        /// </summary>
        public void Draw_Human(OpenGL gl)
        {

            gl.PushMatrix();
            gl.Translate(0.0f, 0.0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Translate(3f,-0.5f,-3.6f);
            //gl.Color(1f, 0.8f, 0.8f);
            gl.Rotate(0f, 180f, 0f);
            m_scene.Draw();
            gl.PopMatrix();

        }

        
        /// <summary>
        /// Iscrtavanje stepenica za scenu.
        /// </summary>
        public void Draw_Stairs(OpenGL gl)
        {
           
            //Valjak 1
            gl.PushMatrix();
            gl.Translate(0.0f, 0.0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0f, 0f, 1f);
            gl.Scale(3,3,3);
            cyl.BaseRadius = 0.5f;
            cyl.TopRadius = 0.5f;
            cyl.Height = 2.0f;
            gl.Translate(0f, -2.45f, -2.1f);
            gl.Rotate(0f, 90f, 0f);
            cyl.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //Valjak2
            gl.PushMatrix();
            gl.Translate(0.0f, 0.0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0f, 0f, 1f);
            gl.Scale(3, 3, 3);
            cyl.BaseRadius = 0.5f;
            cyl.TopRadius = 0.5f;
            cyl.Height = 2.0f;
            gl.Translate(0f, 0.45f, -7f);
            gl.Rotate(0f, 90f, 0f);
            cyl.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //Kais 1/2
            gl.PushMatrix();
            gl.Translate(0.0f, -13.05f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Rotate(31f, 0f, 0f);
            gl.Color(0f, 0f, 1f);
            gl.Scale(3, 0.15, 8.5);
            gl.Translate(1.0f,0f,-2.0f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //Kais 2/2
            gl.PushMatrix();
            gl.Translate(0.0f, -10.25f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Rotate(32f, 0f, 0f);
            gl.Color(0f, 0f, 1f);
            gl.Scale(3, 0.15, 8.0);
            gl.Translate(1.0f, 0f, -1.95f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //Stranica 1/2
            gl.PushMatrix();
            gl.Translate(0.0f, -11.8, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Rotate(32f, 0f, 90f);
            gl.Color(0f, 0f, 1f);
            gl.Scale(1.3, 0.15, 10);
            gl.Translate(0.0f, 0f, -1.68f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            
            
            //Stranica 2/2
            gl.PushMatrix();
            gl.Translate(0.0f, -11.85, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Rotate(32f, 0f, 90f);
            gl.Color(0f, 0f, 1f);
            gl.Scale(1.3, 0.15, 10);
            gl.Translate(0f, -39f, -1.68f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();


            //Stepenice
            //1
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -26f, -6.2f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //2
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -20.9f, -8.2f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //3
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -15.8f, -10.2f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //4
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -10.7f, -12f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //5
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -5.4f, -13.85f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //6
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -0.385f, -15.65f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //7
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, 4.5f, -17.4f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //8
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, 9.3f, -19.15f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //9
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, 13.3f, -20.8f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //Donje stepenice
            //1
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -43.5f, -6.2f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //2
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -38.4f, -8.2f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //3
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -33.8f, -10.2f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //4
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -28.2f, -12f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //5
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -22.9f, -13.85f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //6
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -17.885f, -15.65f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //7
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -13f, -17.4f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //8
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -8.2f, -19.15f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();
            //9
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, -4.2f, -20.8f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //10
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, 0.5f, -21.9f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //11
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0.5f, 0.5f, 0.5f);
            gl.Scale(3, 0.2, 1);
            gl.Translate(1.0f, 7f, -22.6f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            //Ograda
            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0f, 1f, 0f);
            gl.Scale(0.3, 2, 0.3);
            gl.Translate(0.0f,-2f,-14.6f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0f, 1f, 0f);
            gl.Scale(0.3, 2, 0.3);
            gl.Translate(19f, -2f, -14.6f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0f, 1f, 0f);
            gl.Scale(0.3, 2, 0.3);
            gl.Translate(0.0f, 2.0f, -70.1f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            gl.PushMatrix();
            gl.Translate(0.0f, 0f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Color(0f, 1f, 0f);
            gl.Scale(0.3, 2, 0.3);
            gl.Translate(19f, 2.0f, -70.1f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();


            
            gl.PushMatrix();
            gl.Translate(0.0f, -10.25f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Rotate(26f, 0f, 0f);
            gl.Color(0f, 1f, 0f);
            gl.Scale(0.2, 0.15, 9.4);
            gl.Translate(0f, 35f, -1.8f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

            gl.PushMatrix();
            gl.Translate(0.0f, -10.25f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Rotate(26f, 0f, 0f);
            gl.Color(0f, 1f, 0f);
            gl.Scale(0.2, 0.15, 9.4);
            gl.Translate(28.5f, 35f, -1.8f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();


            gl.PushMatrix();
            gl.Translate(0.0f, -2f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Rotate(90f, 0f, 90f);
            gl.Color(0f, 0f, 1f);
            gl.Scale(1, 0.15, 4);
            gl.Translate(-21f, 0f, 0f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();


            gl.PushMatrix();
            gl.Translate(0.0f, -2f, -m_sceneDistance);
            gl.Rotate(m_xRotation, 1.0f, 0.0f, 0.0f);
            gl.Rotate(m_yRotation, 0.0f, 1.0f, 0.0f);
            gl.Rotate(90f, 0f, 90f);
            gl.Color(0f, 0f, 1f);
            gl.Scale(1, 0.15, 4);
            gl.Translate(-21f, -38f, 0f);
            cub.Render(gl, SharpGL.SceneGraph.Core.RenderMode.Render);
            gl.PopMatrix();

        }


        /// <summary>
        /// Iscrtavanje informacija na ekranu.
        /// </summary>
        public void Draw_Info(OpenGL gl)
        {


            //gl.PushMatrix();
            //gl.Ortho2D(0, m_width,0,m_height);
            //gl.Color(0.0f, 0.0f, 1.0f);
            //gl.Translate(0f, 0f, -m_sceneDistance);
            //gl.Scale(5, 5, 5);
            //gl.DrawText3D("Arial bold", 30f, 1f, 0f, "Predmet: Racunarska grafika");
            //gl.DrawText3D("Arial bold", 30, 1f, 0.1f, "Sk.god: 2017/18.");
            //gl.DrawText3D("Arial bold", 30, 1f, 0.1f, "Ime: Milan");
            //gl.DrawText3D("Arial bold", 30, 1f, 0.1f, "Prezime: Hinic");
            //gl.DrawText3D("Arial bold", 30, 1f, 0.1f, "Sifra zad: 11.2");
            //gl.PopMatrix();

            //gl.Ortho2D(m_width/2, m_width, 0, m_height/2);
            gl.MatrixMode(OpenGL.GL_MODELVIEW);
            gl.PushMatrix();
            gl.Translate(0.0f, 0.0f, -5.0f);
            gl.Translate(1.92f, -1.1f, 0f);
            gl.Scale(0.1, 0.1, 0.1);
            gl.DrawText3D("Arial bold", 12f, 1f, 0f, "Predmet: Racunarska grafika");
            gl.Translate(-12.4f, -1f, 0f);
            gl.DrawText3D("Arial bold", 12f, 1f, 0f, "Sk.god: 2017/18.");
            gl.Translate(-7f, -1f, 0f);
            gl.DrawText3D("Arial bold", 12f, 1f, 0f, "Ime: Milan");
            gl.Translate(-4.4f, -1f, 0f);
            gl.DrawText3D("Arial bold", 12f, 1f, 0f, "Prezime: Hinic");
            gl.Translate(-6.15f, -1f, 0f);
            gl.DrawText3D("Arial bold", 12f, 1f, 0f, "Sifra zad: 11.2");
            gl.PopMatrix();


        }


        /// <summary>
        /// Podesava viewport i projekciju za OpenGL kontrolu.
        /// </summary>
        public void Resize(OpenGL gl, int width, int height)
        {
            m_width = width;
            m_height = height;   //Deinisan viewport
            gl.Viewport(0, 0, m_width, m_height);
            gl.MatrixMode(OpenGL.GL_PROJECTION);      // selektuj Projection Matrix
            gl.LoadIdentity();
            gl.Perspective(45f, (double)m_width / (double)m_height, 0.5f, 20000f); //Definisana perspektiva
            gl.MatrixMode(OpenGL.GL_MODELVIEW);
            gl.LoadIdentity();                // resetuj ModelView Matrix
        }

        /// <summary>
        ///  Implementacija IDisposable interfejsa.
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                m_scene.Dispose();
            }
        }

        #endregion Metode

        #region IDisposable metode

        /// <summary>
        ///  Dispose metoda.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion IDisposable metode
    }
}
